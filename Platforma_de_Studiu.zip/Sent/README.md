# Platforma de studiu
- Proiect la disciplina Baze de Date Anul 2021-2022
- Facultatea de Automatică și Calculatoare
- Departamentul de Calculatoare
- Budiul Cristian-Carol - Giesswein Alexia - Kovács Paul-Adrian


## Setup

#### 1. Ruleaza scripturile(`/SQL/tabeleProceduriTrigere.sql` prima): `/SQL/tabeleProceduriTrigere.sql`, `/SQL/proceduriAdmin.sql`, `/SQL/proceduriProfesor.sql`, `/SQL/proceduriStudent.sql`

#### 2. Deschide proiectul Java `/PlatformaDeStudiu` in Eclipse si ruleaza
  
- Vezi `/Documentatie` Capitol 5 Manual de instalare/utilizare pentru mai multe
