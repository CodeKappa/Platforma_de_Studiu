package databaseView_SignUpPanel;

public enum SIGNUP_LABEL {
	NAME,
	PRENUME,
	CNP,
	ADRESS,
	PHONE,
	EMAIL,
	IBAN,
	PASSWORD,
	PASSWORDCONFIRM
}
